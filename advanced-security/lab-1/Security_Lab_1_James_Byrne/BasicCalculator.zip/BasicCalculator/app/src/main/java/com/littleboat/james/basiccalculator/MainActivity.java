package com.littleboat.james.basiccalculator;

import android.os.Bundle;
import android.app.Activity;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity implements OnClickListener {

    // Declare all the buttons, textViews and variables
    EditText editText_Number_1;
    EditText editText_Number_2;

    Button button_Add;
    Button button_Sub;
    Button button_Mult;
    Button button_Div;

    TextView textView_Result;

    String operation = "";

    // Called when the activity is first created (App is started)
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Assign the elements to their variable counterparts
        editText_Number_1 = (EditText) findViewById(R.id.editText_Number_1);
        editText_Number_2 = (EditText) findViewById(R.id.editText_Number_2);

        button_Add = (Button) findViewById(R.id.button_Add);
        button_Sub = (Button) findViewById(R.id.button_Sub);
        button_Mult = (Button) findViewById(R.id.button_Mult);
        button_Div = (Button) findViewById(R.id.button_Div);

        textView_Result = (TextView) findViewById(R.id.tvResult);

        // set listeners on each of the buttons
        button_Add.setOnClickListener(this);
        button_Sub.setOnClickListener(this);
        button_Mult.setOnClickListener(this);
        button_Div.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        float num1 = 0;
        float num2 = 0;
        float result = 0;

        // Check if the fields are empty
        // If so return nothing
        if (TextUtils.isEmpty(editText_Number_1.getText().toString())
                || TextUtils.isEmpty(editText_Number_2.getText().toString())) {
            return;
        }

        // Read EditText and fill variables with numbers
        num1 = Float.parseFloat(editText_Number_1.getText().toString());
        num2 = Float.parseFloat(editText_Number_2.getText().toString());

        // Get which button as been clicked and assign appropriate operations
        switch (view.getId()) {
            case R.id.button_Add:
                operation = "+";
                result = num1 + num2;
                break;
            case R.id.button_Sub:
                operation = "-";
                result = num1 - num2;
                break;
            case R.id.button_Mult:
                operation = "*";
                result = num1 * num2;
                break;
            case R.id.button_Div:
                operation = "/";
                result = num1 / num2;
                break;
            default:
                break;
        }

        // form the output line and give the result
        textView_Result.setText(num1 + " " + operation + " " + num2 + " = " + result);
    }
}